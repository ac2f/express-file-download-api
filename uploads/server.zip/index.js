const fs = require("fs");
const express = require("express");
const crypto = require("crypto");
const axios = require("axios").default;
const sqlite3 = require('sqlite3');
const aes256 = require('aes256');
const { reset } = require("nodemon");
const https = require('https');
const http = require('http');
const cors = require('cors');
// const https = require('https');
var app = express();
// fs.rmSync()
var httpPort = 9870;
var httpsPort = 9871;
var adminPassword = "e316d90fb2dd942ca7e30caffa58bbb77c9a6e3ff94ddd6f4ce145907c5ee534";
app.use(cors({
    origin: "*",
}));
app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});
app.use(express.json());

const hash = text => crypto.createHash("sha1").update(text).digest("base64");
const readJson = path => JSON.parse(fs.readFileSync(path, { encoding: "utf8" }));
var config = readJson("config.json");
var db = new sqlite3.Database(config.dbPath, error => {
    if (error) return process.exit("Couldn't connect to database!");
    console.log("Connected to database!");
    db.run("CREATE TABLE IF NOT EXISTS keys (id INTEGER PRIMARY KEY AUTOINCREMENT, secret TEXT, security TEXT, deadlineMS TEXT, deadlineText TEXT)");
    db.run("CREATE TABLE IF NOT EXISTS misc (id INTEGER PRIMARY KEY AUTOINCREMENT, downloadCount TEXT)");
});
const insertToKeys = (secret, security, deadlineMS, deadlineText) => {
    db.run("INSERT INTO keys (secret, security, deadlineMS, deadlineText) VALUES (?, ?, ?, ?)", [secret, security, deadlineMS, deadlineText], (err, res) => { if (err) console.log("ERR while INSERT process", err); console.log(res); });
};
const insertToMisc = (downloadCount) => {
    db.run("INSERT INTO misc (downloadCount) VALUES (?)", [downloadCount], (err, res) => { if (err) console.log("ERR while INSERT process", err); console.log(res); });
};
const update = (id, secret, security, deadlineMS, deadlineText) => {
    db.run("UPDATE keys SET secret=?, security=?, deadlineMS=?, deadlineText=? where id=? or secret = ?", [secret, security, deadlineMS, deadlineText, id, id], (err, res) => { if (err) console.log("ERR while UPDATE process", err); console.log(res); });
};
const updateKey = (id, key, value) => {
    db.run(`UPDATE keys SET ${key}=? where id=? or secret = ?`, [value, id, id], (err, res) => { if (err) console.log("ERR while single-UPDATE process", err); console.log(res); });
}
const updateMisc = (key, value) => {
    db.run(`UPDATE misc SET ${key}=? where id=?`, [value, 1], (err, res) => { if (err) console.log("ERR while single-UPDATE process", err); console.log(res); });
}
const updateAllKey = (key, value) => {
    db.run(`UPDATE keys SET ${key}=?`, [value], (err, res) => { if (err) console.log("ERR while single-UPDATE process", err); console.log(res); });
}
const selectAll = (table = "keys") => {
    return new Promise(r => db.all(`SELECT * FROM ${table}`, (error, result) => {
        if (error) console.log("ERR while SELECT process", error);
        r(result);
    }));
};
const selectBySecret = secret => {
    return new Promise(r => db.all("SELECT * FROM keys WHERE secret = ?", [secret], (error, result) => {
        if (error) console.log("ERR while SELECT process", error);
        r(result);
    }));
};
const selectById = id => {
    return new Promise(r => db.all("SELECT * FROM keys WHERE id = ?", [id], (error, result) => {
        if (error) console.log("ERR while SELECT process", error);
        r(result);
    }));
};
const delete_ = value => {
    return new Promise(r => db.all("DELETE FROM keys WHERE id = ? or secret=?", [value, value], (error, result) => {
        if (error) console.log("ERR while SELECT process", error);
        r(result);
    }));
};
const deleteAll = () => {
    return new Promise(r => db.all("DELETE FROM keys", (error, result) => {
        if (error) console.log("ERR while SELECT process", error);
        r(result);
    }));
};
const beautify = (object, space = 2) => JSON.stringify(object, null, space);
const a = value => value.toString().length < 2 ? "0" + value : value;
const timestampToDate = timestamp => { var d = new Date(timestamp); return `${a(d.getHours())}:${a(d.getMinutes())}:${a(d.getSeconds())}, ${a(d.getDate())} ${a(['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getMonth()])} ${a(d.getFullYear())}`; };
const nT = (value) => value === "null" ? null : value;
const cpass = (request) => request.headers.password === adminPassword;
const downloadCheck = async (request, r, passSuccessResponse = false) => {
    const res = (message, error = false, status = 200) => [r.status(status), r.send(beautify({ error: error, message: message }))];
    try {
        if (!request.headers.security) return res("H-Fail check!", true);
        var securityData = request.headers.security.split(":");
        var securityValue = "";
        if (!securityData || ((typeof securityData === typeof "") && securityData.length < 10))
            return res("Enter secret key!", true);
        securityValue = securityData[1];
        if (securityValue.length <= 9)
            return res("Invalid password!", true);
        var secret = securityData[0];
        var filtered = await selectBySecret(secret);
        if (filtered.length < 1) return res("Invalid secret key!", true);
        filtered = filtered[0];
        if (filtered.security !== "" && filtered.security !== securityValue) return res("Invalid security code! Contact with an administrator..", true);
        if (filtered.security === "") {
            update(filtered.id, filtered.secret, securityValue, filtered.deadlineMS, filtered.deadlineText);
        }
        passSuccessResponse !== true && res("Success!", false, 200);
    } catch (error) {
        res(`${error}`);
    }
};
app.get("/files", async (request, r) => {
    const res = (message, files, error = false, status = 200) => [r.status(status), r.send(beautify({ error: error, message: message, files: files }))];
    if (cpass(request)) {
        return res("Success!", fs.readdirSync(config.filesPath), false, 200);
    }
    res("Permission denied!", [], true, 502);
});
app.delete("/file", async (request, r) => {
    const res = (message, error = false, status = 200) => [r.status(status), r.send(beautify({ error: error, message: message }))];
    if (cpass(request)) {
        var file = nT(request.body.file);
        if (fs.existsSync(file))
            fs.rm(`${config.filesPath}/${file}`);
        return res("Success!", false, 200);
    }
    res("Permission denied!", [], true, 502);
});
app.put("/file", async (request, r) => {
    const res = (message, error = false, status = 200) => [r.status(status), r.send(beautify({ error: error, message: message }))];
    if (cpass(request)) {
        var file = nT(request.body.file);
        var fileName =nT(request.body.fileName);
        fs.writeFileSync(`${config.filesPath}/${fileName}`, Buffer.from(file));
        return res("Success!", false, 200);
    }
    res("Permission denied!", [], true, 502);
});
app.get("/config", async (request, r) => {
    const res = (message, config, error = false, status = 200) => [r.status(status), r.send(beautify({ error: error, message: message, config: config }))];
    config = readJson("config.json");
    cpass(request) ? res("Success!", config, false, 200) : res("Permission denied!", {}, true, 502);
});
app.put("/config", async (request, r) => {
    const res = (message, config, error = false, status = 200) => [r.status(status), r.send(beautify({ error: error, message: message, config: config }))];
    if (cpass(request)) {
        fs.writeFileSync("config.json", JSON.stringify(request.body, null, 4), { encoding: "utf8" });
        config = readJson("config.json");
        return res("Success!", config, false, 200);
    }
    res("Permission denied!", {}, true, 502);
});
app.get("/info", async (request, r) => {
    const res = (message, downloads, error = false, status = 200) => [r.status(status), r.send(beautify({ error: error, message: message, downloads: downloads }))];
    var misc = await selectAll("misc");
    if (misc.length < 1) {
        insertToMisc(config.defaultDownloadCountValue);
        misc = {};
        misc.downloadCount = config.defaultDownloadCountValue;
        misc = [misc];
    }
    misc = misc[0];
    res("Success!", misc.downloadCount, false, 200);
});
app.put("/info", async (request, r) => {
    const res = (message, downloads, error = false, status = 200) => [r.status(status), r.send(beautify({ error: error, message: message, downloads: downloads }))];
    if (cpass(request)) {
        var misc = await selectAll("misc");
        if (misc.length < 1) {
            insertToMisc(config.defaultDownloadCountValue);
            misc = {};
            misc.downloadCount = config.defaultDownloadCountValue;
            misc = [misc];
        }
        misc = misc[0];
        var downloadCount = request.body.downloadCount ? request.body.downloadCount : misc.downloadCount;
        await updateMisc("downloadCount", downloadCount);
        return res("Success!", downloadCount, false, 200);
    }
    res("Permission denied!", 0, true, 502);
});
app.get("/keys", async (request, r) => {
    const res = (message, keys, error = false, status = 200) => [r.status(status), r.send(beautify({ error: error, message: message, keys: keys }))];
    if (cpass(request)){
        var id = nT(request.body.id);
        var secret = nT(request.body.secret);
        return res("Success!", await (id ? selectById(id) : secret ? selectBySecret(secret) : selectAll()), false, 200);
    }
    res("Permission denied!", [], true, 502);
});
app.delete("/delete", async (request, r) => {
    const res = (message, error = false, status = 200) => [r.status(status), r.send(beautify({ error: error, message: message }))];
    if (cpass(request)) {
        var value = nT(request.body.value);
        await (value ? delete_(value) : deleteAll());
        return res("Success!", false, 200);
    }
    res("Permission denied!", true, 502);
});
app.post("/generate", async (request, r) => {
    const res = (message, generated, deadlineMS, deadlineText, error = false, status = 200) => [r.status(status), r.send(beautify({ error: error, message: message, deadlineMS: deadlineMS, deadlineText: deadlineText, keys: generated }))];
    if (cpass(request)) {
        var count = nT(request.body.count);
        var days = nT(request.body.d) ? nT(request.body.d) : (365 * 25);
        var deadlineMS = Date.now() + (parseInt(days + "") * 1000 * 60 * 60 * 24);
        var addedKeys = [];
        for (let index = 0; index < count; index++) {
            var key = crypto.randomBytes(32).toString("hex");
            insertToKeys(key, "", deadlineMS.toString(), timestampToDate(deadlineMS));
            addedKeys.push(key);
        }
        return res("Success!", addedKeys, deadlineMS, timestampToDate(deadlineMS), false, 200);
    }
    res("Permission denied!", [],  0, "0",true, 502);
});
app.post("/resetSecurity", async (request, r) => {
    const res = (message, error = false, status = 200) => [r.status(status), r.send(beautify({ error: error, message: message }))];
    if (cpass(request)) {
        var value = nT(request.body.value);
        await (value ? updateKey(value, "security", "") : updateAllKey("security", ""));
        return res("Success!", false, 200);
    }
    res("Permission denied!", true, 502);
});
app.put("/update", async (request, r) => {
    const res = (message, error = false, status = 200) => [r.status(status), r.send(beautify({ error: error, message: message }))];
    if (cpass(request)) {
        var id = nT(request.query.id);
        var secret = nT(request.query.secret);
        var security = nT(request.query.security);
        var days = nT(request.query.d);
        var deadlineMS = nT(request.query.deadlineMS) ? nT(request.query.deadlineMS) : (days ? (Date.now() + (parseInt(days + "") * 1000 * 60 * 60 * 24)) : null);
        var d = await selectById(id);
        if (d.length < 1) return res("Invalid ID!", true);
        d = d[0];
        await update(id, secret ? secret : d.secret, security ? security : d.security, deadlineMS ? deadlineMS : d.deadlineMS, timestampToDate(parseInt(deadlineMS ? deadlineMS : d.deadlineMS)));
        return res("Success!", false, 200);
    }
    res("Permission denied!", true, 502);
});
app.get("/checkDownload", downloadCheck);
app.get("/download", async (request, r) => {
    const res = (message, error = false, status = 200) => [r.status(status), r.send(beautify({ error: error, message: message }))];
    downloadCheck(request, r, true);
    try {
        var file = nT(request.query.file);
        if (config.sendStaticFile) file = config.staticFile;
        var path = `${config.filesPath}/${file}`;
        console.log(file);
        if (!fs.existsSync(path))
            return res(`Couldn\'t find file specified! File: "${file}"`, true);
        var misc = await selectAll("misc");
        if (misc.length < 1) {
            insertToMisc(config.defaultDownloadCountValue);
            misc = {};
            misc.downloadCount = config.defaultDownloadCountValue;
            misc = [misc];
            console.log(misc);
        } else {
            var newVal = parseInt(misc[0].downloadCount) + 1;
            db.run("UPDATE misc SET downloadCount = ? where id=1", [newVal.toString()], (err, response) => { if (err) console.log("ERROR while UPDATE", err); console.log("UPDATED misc! New value:", newVal); });
        }
        console.log("buf", fs.readFileSync(path));
        r.send(beautify({ "error": false, "message": "Success!", "content": fs.readFileSync(path), "fileName": file }));
    } catch (error) {
        console.log(error);
    }
});
// var httpsServer = https.createServer({
//     key: fs.readFileSync("key.pem"),
//     cert: fs.readFileSync("cert.pem"),
// }, app);
// httpsServer.listen(port, () => {
//     console.log(`Running at ${port}`);
// })

https.createServer({
    key: fs.readFileSync('server.key'),
    cert: fs.readFileSync('server.cert')
}, app).listen(httpsPort, () => {
    console.log(`Running HTTPS at ${httpsPort}`);
});
app.listen(httpPort, () => {
    console.log(`Running HTTP at ${httpPort}`);
});